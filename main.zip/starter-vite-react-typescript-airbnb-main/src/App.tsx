import appStyle from '@/styles/appStyle';

const App = (): JSX.Element => (
  <div className="app" css={appStyle}>
    <div>Hello World</div>
  </div>
);

export default App;
