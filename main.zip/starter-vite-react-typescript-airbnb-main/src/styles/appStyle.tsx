import { css } from '@emotion/react';

const appStyle = css`
  /* appStyle */
`;

export default appStyle;
